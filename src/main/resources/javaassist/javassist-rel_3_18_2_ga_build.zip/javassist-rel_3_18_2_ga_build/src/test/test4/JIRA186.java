package test4;

public class JIRA186 {
	public int test() {
		return 1;
	}
}
