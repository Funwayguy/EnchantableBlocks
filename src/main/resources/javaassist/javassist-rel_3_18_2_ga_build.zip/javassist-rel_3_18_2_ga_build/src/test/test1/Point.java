package test1;

public class Point {
    public int x, y;
}
