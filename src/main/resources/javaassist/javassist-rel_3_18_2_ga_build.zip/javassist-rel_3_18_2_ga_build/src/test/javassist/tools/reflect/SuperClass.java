package javassist.tools.reflect;

public class SuperClass {
    public String f() { return "f"; }
    public String g() { return "g"; }
    public final String h() { return "h"; }
}
