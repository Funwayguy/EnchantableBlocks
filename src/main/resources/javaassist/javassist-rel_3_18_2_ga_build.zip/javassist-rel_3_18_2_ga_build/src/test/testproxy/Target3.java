package testproxy;

public interface Target3 {
    String m();
    String toString();
}
