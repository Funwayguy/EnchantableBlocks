package test4;

public @interface Anno1 {
    String value() default "empty";
}
